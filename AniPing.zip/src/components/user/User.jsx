const User = () => {

    return (
        <div>
            <div>
            </div>
        </div>
    )

}

export default User;