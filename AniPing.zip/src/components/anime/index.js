import AniCha from "./AniCha";
import AniComment from "./AniComment";
import AniInfo from "./AniInfo";
import AniPv from "./AniPv";
import AniTag from "./AniTag";


export {AniCha,AniComment,AniInfo,AniPv,AniTag};