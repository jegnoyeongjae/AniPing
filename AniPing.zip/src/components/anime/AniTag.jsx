const AniTag=()=>{
    return(
        <div className="AniTag">
            
        </div>
    )
}

export default AniTag;