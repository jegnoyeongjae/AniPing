const AniPv=()=>{
    return(
        <div className="AniPv">
            
        </div>
    )
}

export default AniPv;