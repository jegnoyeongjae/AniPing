const AniComment=()=>{
    return(
        <div className="AniComment">
            
        </div>
    )
}

export default AniComment;