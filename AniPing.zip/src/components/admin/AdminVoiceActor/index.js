import AdminVALi from "./AdminVALi";
import AdminVALiEd from "./AdminVALiEd";

export {AdminVALi, AdminVALiEd};