import Anime from "./anime/Anime";


export {Anime};