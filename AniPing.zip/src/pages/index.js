import HomePage from "./HomePage";
import AniList from "./anime/AniList";
import AniDetail from "./anime/AniDetail";


export {HomePage,AniList,AniDetail};

