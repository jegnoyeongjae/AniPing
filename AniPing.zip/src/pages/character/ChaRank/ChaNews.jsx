import './ChaNews.css';

const ChaNews = () => {
  return <div className="ChaNews"></div>;
};
export default ChaNews;
