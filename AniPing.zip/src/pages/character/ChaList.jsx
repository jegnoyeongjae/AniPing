import './ChaList.css';

const ChaList = () => {
  return <div className="ChaList"></div>;
};
export default ChaList;
