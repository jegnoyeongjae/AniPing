

import './AdList.css'

const AdList = () => {

    return (
        <div id="AdList">
        </div>
    )

}

export default AdList;